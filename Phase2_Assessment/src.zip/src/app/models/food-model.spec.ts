import { FoodModel } from './food-model';

describe('FoodModel', () => {
  it('should create an instance', () => {
    expect(new FoodModel()).toBeTruthy();
  });
});

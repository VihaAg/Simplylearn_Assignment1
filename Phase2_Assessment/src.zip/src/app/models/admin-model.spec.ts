import { AdminModel } from './admin-model';

describe('AdminLoginModel', () => {
  it('should create an instance', () => {
    expect(new AdminModel()).toBeTruthy();
  });
});

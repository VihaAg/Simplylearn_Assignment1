import { CartModel } from './cart-model';

describe('CartModel', () => {
  it('should create an instance', () => {
    expect(new CartModel()).toBeTruthy();
  });
});

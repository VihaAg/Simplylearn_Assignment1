import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-cart',
  templateUrl: './food-cart.component.html',
  styleUrls: ['./food-cart.component.css']
})
export class FoodCartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
